# Car-Number-Plate-Detection---AI-
**This project helps to detect the number plate of a car as well as the words written on the number plate.**

**It uses following steps :****

**1.Read in Image,Grascale and Blur.**

![Screenshot 2023-04-19 004904](https://user-images.githubusercontent.com/73659977/232882887-22569171-3e01-4c63-95a3-945c2dfc87c8.png)

**2.Apply filters and find edges for localisation.**

![Screenshot 2023-04-19 004917](https://user-images.githubusercontent.com/73659977/232882943-7a4af4f3-bacb-4856-86d6-117e93e343b7.png)

**3.Find Contours and Apply Mask.**

![Screenshot 2023-04-19 004929](https://user-images.githubusercontent.com/73659977/232883000-446cdead-4ac0-49b7-923d-453d7b5c63ff.png)

**4.Use easy OCR Ro Read Text.**

![Screenshot 2023-04-19 004939](https://user-images.githubusercontent.com/73659977/232883019-bd0e7441-dae1-4a78-b021-50f2531df27e.png)

**5.Render Result.**

![Screenshot 2023-04-19 004948](https://user-images.githubusercontent.com/73659977/232883034-86ee6d46-4e64-4b90-b075-6c37504dfeb6.png)
